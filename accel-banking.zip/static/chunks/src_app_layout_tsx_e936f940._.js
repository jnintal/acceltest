(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/[root of the server]__9d34396b._.css",
    "static/chunks/node_modules_next_dist_2067ba8c._.js",
    "static/chunks/src_app_ClientBody_tsx_a9fb1e66._.js"
  ],
  "source": "dynamic"
});
